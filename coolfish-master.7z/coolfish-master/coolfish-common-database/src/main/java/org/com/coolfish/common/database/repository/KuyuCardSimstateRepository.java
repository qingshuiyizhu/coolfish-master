package org.com.coolfish.common.database.repository;

import org.com.coolfish.common.database.entity.KuyuCardSimstate;
import org.springframework.data.jpa.repository.JpaRepository;

public interface KuyuCardSimstateRepository extends JpaRepository<KuyuCardSimstate, Integer> {
}