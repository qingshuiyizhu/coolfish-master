package org.com.coolfish.common.webinterface.cmcc.xml.content;

@SuppressWarnings("unused")
public class QrycycleContent {
	// 集团编码
	private String groupid = "";
	// 号码
	private String telnum = "";

	public QrycycleContent(String groupid, String telnum) {
		super();
		this.groupid = groupid;
		this.telnum = telnum;
	}

}
