package org.com.coolfish.cmcc.monthly.service;

import org.apache.commons.lang.StringUtils;
import org.com.coolfish.common.database.service.ComDBService;
import org.com.coolfish.common.message.MsisdnMessage;
import org.com.coolfish.common.model.CMCCOperator;
import org.com.coolfish.common.model.DisabledBean;
import org.com.coolfish.common.model.UtilBean;
import org.com.coolfish.common.util.DecimalTools;
import org.com.coolfish.common.webinterface.service.CMCCRequestService;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * @author LINGHUI
 * @desc 中国移动http 请求API
 */
@Service
@Slf4j
public class CMCCSilentService {

    @Autowired
    private CMCCRequestService requestService;

    @Autowired
    private AmqpTemplate rabbitTemplate;
    @Autowired
    private ComDBService databaseService;
    /*
     * 沉默期处理
     * 
     * 
     * 
     * 
     */
    public void HandleQuery(CMCCOperator operator, MsisdnMessage msisdnMessage) {
        UtilBean requestBean = new UtilBean();
        requestBean.setCardId(msisdnMessage.getCardid());
        requestBean.setIccid(msisdnMessage.getIccid());
        requestBean.setIphone(msisdnMessage.getIphone());

        requestBean = requestService.queryTraffic(operator, requestBean);

        double realApiflow = 0D;
        if (StringUtils.isNotBlank(requestBean.getAnalyze())) {
            String nowApifow = requestBean.getAnalyze();
            // 实际使用量
            realApiflow = DecimalTools.div(nowApifow, msisdnMessage.getPer(), 2);
            msisdnMessage.setUseflow(String.valueOf(realApiflow));
        }

        // 查询状态
        requestBean = requestService.queryStatus(operator, requestBean);

        String startusCode = requestBean.getResultCode();

        String cardStatus = requestBean.getResultMsg();

        msisdnMessage.setStartusCode(startusCode);
        msisdnMessage.setCardStatus(cardStatus);

        double subResult = DecimalTools.sub(realApiflow, 512D);
        if (DecimalTools.compareTo(subResult, 0d) > -1) {
            log.info("移动物联网卡ID[{}]由沉默期转为在用,已使用量[{} kb],进行套餐激活", msisdnMessage.getCardid(), realApiflow);
          
         //   databaseService.flashSlientStatus(msisdnMessage.getCardid());
            
            
        } else {
            log.info("移动物联网卡ID[{}]处于沉默期,已使用量[{} kb],不处理", msisdnMessage.getCardid(), realApiflow);
        }

    }

    
}
