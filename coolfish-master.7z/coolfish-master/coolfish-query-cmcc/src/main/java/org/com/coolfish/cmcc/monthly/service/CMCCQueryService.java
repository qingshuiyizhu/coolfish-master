package org.com.coolfish.cmcc.monthly.service;

import org.apache.commons.lang.StringUtils;
import org.com.coolfish.common.message.MsisdnMessage;
import org.com.coolfish.common.model.CMCCOperator;
import org.com.coolfish.common.model.UtilBean;
import org.com.coolfish.common.util.DecimalTools;
import org.com.coolfish.common.webinterface.service.CMCCRequestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * @author LINGHUI
 * @desc 中国移动http 请求API
 */
@Service
@Slf4j
public class CMCCQueryService {

    @Autowired
    private CMCCRequestService requestService;

    @Autowired
    private RedisService redisService;

    public void HandleQuery(CMCCOperator operator, MsisdnMessage msisdnMessage) {
        // 查询电信当月使用量
        UtilBean requestBean = new UtilBean();
        requestBean.setCardId(msisdnMessage.getCardid());
        requestBean.setIccid(msisdnMessage.getIccid());
        requestBean.setIphone(msisdnMessage.getIphone());

        requestBean = requestService.queryTraffic(operator, requestBean);

        double realApiflow = 0D;
        if (StringUtils.isNotBlank(requestBean.getAnalyze())) {
            String nowApifow = requestBean.getAnalyze();
            // 实际使用量
            realApiflow = DecimalTools.div(nowApifow, msisdnMessage.getPer(), 2);
            msisdnMessage.setUseflow(String.valueOf(realApiflow));
        }

        // 查询状态
        requestBean = requestService.queryStatus(operator, requestBean);

        String startusCode = requestBean.getResultCode();

        String cardStatus = requestBean.getResultMsg();

        msisdnMessage.setStartusCode(startusCode);
        msisdnMessage.setCardStatus(cardStatus);

        // 数据同步到Redis缓存上
        redisService.set(String.valueOf(msisdnMessage.getCardid()),
                JSON.toJSONString(msisdnMessage).toString());
        log.info("移动物联网卡ID[{}]物联网卡信息更新到Redis缓存中,{}", msisdnMessage.getCardid(),JSON.toJSONString(msisdnMessage).toString());

    
    //判断是否停机
        // 使用量/总流量
        double rate = DecimalTools.div(msisdnMessage.getUseflow(), msisdnMessage.getSumflow(), 2);
 
        if (DecimalTools.compareTo(rate, 0.99d) > -1 && "1".equals(msisdnMessage.getStartusCode())) {
       //查询当月流量
            
            //调用停机方法 
            
            
            
        }else {
            
            
            
            
        }
     }

}
