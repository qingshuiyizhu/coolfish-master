package org.com.coolfish.common.spi.controller;
import org.com.coolfish.common.cache.CTCCAccountCache;
import org.com.coolfish.common.model.CTCCOperator;
import org.com.coolfish.common.model.DisabledBean;
import org.com.coolfish.common.model.UtilBean;
import org.com.coolfish.common.spi.service.AccountCacheService;
import org.com.coolfish.common.spi.service.CTCCSwitchService;
import org.com.coolfish.common.webinterface.service.CTCCResquestService;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("ctcc")
public class CTCCController {
    // 不关联账户密钥表
    private final static int NOZID = 0;
    @Autowired
    private AccountCacheService accountCacheService;
    @Autowired
    private CTCCResquestService requestService;
    @Autowired
    private CTCCSwitchService ctccSwitchService;

    // 查询流量
    @RequestMapping(value = "queryTraffic", method = RequestMethod.POST)
    public UtilBean queryTraffic(@RequestBody UtilBean requestBean) {
        CTCCOperator operator = getCTCCOperator(requestBean.getOperatorid(), requestBean.getZid());
        if (operator == null) {
            requestBean.setResultCode("-1");
            requestBean.setResultMsg("系统匹配供应商账号错误");
        } else {
            requestBean = requestService.queryTraffic(operator, requestBean);
        }
        return requestBean;
    }
    
    // 查询状态
    @RequestMapping(value = "queryStatus", method = RequestMethod.POST)
    public UtilBean queryStatus(@RequestBody UtilBean requestBean) {
        CTCCOperator operator = getCTCCOperator(requestBean.getOperatorid(), requestBean.getZid());
        if (operator == null) {
            requestBean.setResultCode("-1");
            requestBean.setResultMsg("系统匹配供应商账号错误");
        } else {
            requestBean = requestService.queryStatus(operator, requestBean);
        }
        return requestBean;
    
    
    }

    // 停复机
    @RequestMapping(value = "disabledNumber", method = RequestMethod.POST)
    public DisabledBean disabledNumber(@RequestBody DisabledBean requestBean) {
        CTCCOperator operator = getCTCCOperator(requestBean.getOperatorid(), requestBean.getZid());
        if (operator == null) {
            requestBean.setResultCode("-1");
            requestBean.setResultMsg("系统匹配供应商账号错误");
        } else {
            requestBean = ctccSwitchService.HandleDisabled(operator, requestBean);
        }
        return requestBean;
    }
    
    private CTCCOperator getCTCCOperator(Integer peratorid, Integer zid) {
        CTCCOperator operator = null;
        if (NOZID == zid) {
            operator = CTCCAccountCache.getInstance().getOperator(peratorid);
            if (null == operator) {
                accountCacheService.getOneOperator(peratorid);
                operator = CTCCAccountCache.getInstance().getOperator(peratorid);
            }
        } else {
            // 关联独立的账号表
            operator = CTCCAccountCache.getInstance().getAccount(zid);
            if (null == operator) {
                accountCacheService.getOneAccount(zid);
                operator = CTCCAccountCache.getInstance().getAccount(zid);
            }
        }
        return operator;
    }
}
