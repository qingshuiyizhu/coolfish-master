package org.com.coolfish.cmcc.service;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.com.coolfish.common.cache.CMCCAccountCache;
import org.com.coolfish.common.model.CMCCOperator;
import org.com.coolfish.common.model.DisabledBean;
import org.springframework.amqp.rabbit.annotation.RabbitHandler;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSON;

import lombok.extern.slf4j.Slf4j;

@Component
@RabbitListener(queues = "switch-cmcc")
@Slf4j
public class CMCCRabbitListener {

    @Autowired
    private CMCCSwitchService cmccSwitchService;

    @Autowired
    private AccountCacheService accountCacheService;

    // 不关联账户密钥表
    private final static int NOZID = 0;

    private final static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    // 停复机队列
    @RabbitHandler
    public void process(String message) {
        log.info("移动停复机队列(switch-cmcc)获取数据[{}]", message);
        DisabledBean disabledBean = JSON.parseObject(message, DisabledBean.class);
        long startTime = System.currentTimeMillis();
        log.info("移动物联网卡ID[{}]开始执行停复机操作, 开始执行时间:{}, 时间戳:{}", disabledBean.getCardId(),
                sdf.format(new Date(startTime)), startTime);

        if (StringUtils.isBlank(disabledBean.getActionReason())) {
            log.warn("操作原因为空---忽略请求");

        }else if (StringUtils.isBlank(disabledBean.getSource())) {
            log.warn("来源为空---忽略请求");
        } else {
            handleMessage(disabledBean);
        }
        long endTime = System.currentTimeMillis();
        log.info("移动物联网卡ID[{}]结束执行停复机操作, 结束执行时间:{}, 时间戳:{}, 耗时:{}ms", disabledBean.getCardId(),
                sdf.format(new Date(endTime)), endTime, (endTime - startTime));
    }

    // 处理监听到的数据
    public void handleMessage(DisabledBean disabledBean) {
        // 请求移动API的需要的密钥对象
        CMCCOperator operator = null;
        if (NOZID >= disabledBean.getZid()) {
            // 账号信息以json格式文本存在text字段上
            Integer id = disabledBean.getOperatorid();
            operator = CMCCAccountCache.getInstance().getOperator(id);
            if (null == operator) {
                accountCacheService.getOneOperator(id);
                operator = CMCCAccountCache.getInstance().getOperator(id);
            }
        } else {
            // 关联独立的账号表
            Integer id = disabledBean.getZid();
            operator = CMCCAccountCache.getInstance().getAccount(id);
            if (null == operator) {
                accountCacheService.getOneAccount(id);
                operator = CMCCAccountCache.getInstance().getAccount(id);
            }
        }
        if (null == operator) {
            log.warn("移动物联网卡ID[{}]没有找到移动供应商的账号信息", disabledBean.getCardId());
        } else {
            log.info("移动物联网卡ID[{}]调用移动执行停复机操作服务,运营商账号信息：{}", disabledBean.getCardId(), operator.toString());
            cmccSwitchService.HandleDisabled(operator, disabledBean);
        }

    }
}
