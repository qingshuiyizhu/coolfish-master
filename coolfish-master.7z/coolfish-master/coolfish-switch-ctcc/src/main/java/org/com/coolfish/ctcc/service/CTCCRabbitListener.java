package org.com.coolfish.ctcc.service;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.com.coolfish.common.cache.CTCCAccountCache;
import org.com.coolfish.common.model.CTCCOperator;
import org.com.coolfish.common.model.DisabledBean;
import org.springframework.amqp.rabbit.annotation.RabbitHandler;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSON;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
@RabbitListener(queues = "switch-ctcc")
public class CTCCRabbitListener {

    @Autowired
    private CTCCSwitchService ctccSwitchService;

    @Autowired
    private AccountCacheService accountCacheService;

    // 标识 不关联账户密钥表
    private final static int NOZID = 0;

    private final static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    @RabbitHandler
    public void process(String message) {
        log.info("电信停复机操作队列(switch-ctcc)获取数据[{}]", message);
        DisabledBean disabledBean = JSON.parseObject(message, DisabledBean.class);
        long startTime = System.currentTimeMillis();
        log.info("电信物联网卡ID[{}]开始执行停复机操作, 开始执行时间:{}, 时间戳:{}", disabledBean.getCardId(),
                sdf.format(new Date(startTime)), startTime);
        if (StringUtils.isBlank(disabledBean.getActionReason())) {
            log.warn("操作原因为空---忽略请求");
        }else if (StringUtils.isBlank(disabledBean.getSource())) {
            log.warn("来源为空---忽略请求");

        } else {
            handleMessage(disabledBean);
        }
        long endTime = System.currentTimeMillis();
        log.info("电信物联网卡ID[{}]结束停复机操作, 结束执行时间:{}, 时间戳:{}, 耗时:{}ms", disabledBean.getCardId(),
                sdf.format(new Date(endTime)), endTime, (endTime - startTime));
    }

    // 处理监听到的数据
    public void handleMessage(DisabledBean disabledBean) {
        // 请求电信API的需要的密钥对象
        CTCCOperator operator = null;
        if (NOZID == disabledBean.getZid()) {
            // 账号信息以json格式文本存在Operator的text字段上
            Integer id = disabledBean.getOperatorid();
            operator = CTCCAccountCache.getInstance().getOperator(id);
            if (null == operator) {
                accountCacheService.getOneOperator(id);
                operator = CTCCAccountCache.getInstance().getOperator(id);
            }
        } else {
            // 关联独立的账号表
            Integer id = disabledBean.getZid();
            operator = CTCCAccountCache.getInstance().getAccount(id);
            if (null == operator) {
                accountCacheService.getOneAccount(id);
                operator = CTCCAccountCache.getInstance().getAccount(id);
            }
        }
        if (null == operator) {
            log.error("电信物联网卡ID[{}]没有找到对应供应商的账号信息", disabledBean.getCardId());
        } else {
            log.info("电信物联网卡ID[{}]调用电信复机操作服务,运营商账号信息：{}", disabledBean.getCardId(), operator.toString());
            ctccSwitchService.HandleDisabled(operator, disabledBean);
        }
    }

}
