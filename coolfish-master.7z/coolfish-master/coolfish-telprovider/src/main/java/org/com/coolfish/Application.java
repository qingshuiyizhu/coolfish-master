package org.com.coolfish;

import org.com.coolfish.scheduler.MsisdnEmptyScheduler;
import org.com.coolfish.scheduler.MsisdnMonthlyScheduler;
import org.com.coolfish.scheduler.MsisdnSilentScheduler;
import org.com.coolfish.scheduler.MsisdnStartScheduler;
import org.com.coolfish.scheduler.StopMonthlyNullSumFlow;
import org.com.coolfish.service.ActionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class Application implements CommandLineRunner {
    @Autowired
    private MsisdnEmptyScheduler msisdnEmptyScheduler;

    @Autowired
    private MsisdnMonthlyScheduler msisdnMonthlyScheduler;

    @Autowired
    private MsisdnSilentScheduler msisdnSilentScheduler;

    @Autowired
    private MsisdnStartScheduler msisdnStartScheduler;
    @Autowired
    private StopMonthlyNullSumFlow stopMonthlyNullSumFlow;
    
    
    
    @Autowired
    private ActionService actionService;
    
    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
       
        System.out.println("开始执行月套餐监控测试操作");
        stopMonthlyNullSumFlow.stopMonthlyNullSumFlow();
     

    }

 

}
