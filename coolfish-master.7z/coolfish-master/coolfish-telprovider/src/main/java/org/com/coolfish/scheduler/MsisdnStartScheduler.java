package org.com.coolfish.scheduler;

import java.util.List;

import org.com.coolfish.common.database.entity.KuyuAddPackage;
import org.com.coolfish.common.database.entity.KuyuCard;
import org.com.coolfish.common.database.service.KuyuAddPackageService;
import org.com.coolfish.common.database.service.KuyuCardService;
import org.com.coolfish.common.message.MsisdnMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;

@Service
public class MsisdnStartScheduler {
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private KuyuCardService kuyuCardService;

    @Autowired
    private AmqpTemplate rabbitTemplate;

    private final static int CMCC = 1;

    private final static int CTCC = 2;

    @Autowired
    private KuyuAddPackageService kuyuaddPackageService;

    public void startStart() {
        
        logger.info("#####执行定时计划任务：执行号码开机查询#####");
        // 组合查询出卡号码的供应商id，套餐总流量等信息
        List<KuyuAddPackage> addpackages = kuyuaddPackageService.findStart();
     
        logger.info("进行空套餐处理所有号码数量：" + addpackages.size());
        KuyuCard card = null;
        for (KuyuAddPackage addpackage : addpackages) {
            try {
                if(0<addpackage.getCardId()) {
                    card= kuyuCardService.get(addpackage.getCardId());
                  }
                    if(card !=null) {
                        MsisdnMessage message =null;/* new MsisdnMessage(card.getTel(), card.getOperatorid(), card.getZid(),
                                null, null, null,null,
                               "1", 0, 0, card.getId(), null,
                                "1");*/
                        String json = JSON.toJSONString(message).toString();
                        // 移动号码空套餐处理队列
                        if (CMCC == card.getOperator_type()) {
                            rabbitTemplate.convertAndSend("cmcc-start", json);
                            logger.info("加入移动号码复机处理队列(cmcc-start),封装的message为：" + json);
                            // 电信号码空套餐处理队列
                        } else if (CTCC == card.getOperator_type()) {
                            rabbitTemplate.convertAndSend("ctcc-start", json);
                            logger.info("加入电信号码复处理队列(ctcc-start),封装的message为：" + json);
                        } 
                    }
            } catch (Exception e) {
                logger.error("------------错误"); 
            }
         
      
        } 
    }
}
