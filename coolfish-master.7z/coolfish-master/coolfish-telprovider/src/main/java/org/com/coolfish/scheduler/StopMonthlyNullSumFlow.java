package org.com.coolfish.scheduler;

import java.math.BigDecimal;
import java.util.List;

import org.com.coolfish.common.database.entity.KuyuCard;
import org.com.coolfish.common.database.service.KuyuAddPackageService;
import org.com.coolfish.common.database.service.KuyuCardService;
import org.com.coolfish.service.ActionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@Service
public class StopMonthlyNullSumFlow {

    @Autowired
    private KuyuCardService kuyuCardService;
    @Autowired
    private KuyuAddPackageService kuyuAddPackageService;
    @Autowired
    private ActionService action;
    

   
    public void stopMonthlyNullSumFlow() {
        log.info("#####执行定时计划任务：执行当月未订购套餐号码查询#####");
/*
    当月未订购套餐的池卡月卡 进行停机
 
 */
     List<KuyuCard> list = kuyuCardService.findMonthlyNullSumFlow();
        for (KuyuCard kuyuCard : list) {
            BigDecimal sumflow =null;
            try {
                sumflow =   kuyuAddPackageService.findMonthlyNullSumFlow(kuyuCard.getId());
            } catch (Exception e) {
               
            }
           if(null ==sumflow) {
               //查询状态，正常，进行停机
               action.stopMonthlyNullSumFlow(kuyuCard);
                
           }
              }
        }
    }


